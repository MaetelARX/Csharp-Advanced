﻿namespace LineNumbers
{
    using System;
    using System.Text;

    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";
            string outputFilePath = @"..\..\..\output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            StringBuilder sb = new StringBuilder();

            string[] input = File.ReadAllLines(inputFilePath);
            int count = 0;

            for (int i = 0; i < input.Length; i++)
            {
                count++;
                int characters = input[i].Count(char.IsLetter);
                int occurance = input[i].Count(char.IsPunctuation);

                sb.AppendLine($"Line {count}: {input[i]} ({characters})({occurance})");
            }
            File.WriteAllText(outputFilePath, sb.ToString());
        }
    }
}